from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disease.db'
db = SQLAlchemy(app)

class SymptomSeverity(db.Model):
    symptom = db.Column(db.String, primary_key=True)
    weight = db.Column(db.Integer)

class SymptomPrecaution(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    disease = db.Column(db.String)
    precaution_1 = db.Column(db.String)
    precaution_2 = db.Column(db.String)
    precaution_3 = db.Column(db.String)
    precaution_4 = db.Column(db.String)

class SymptomDescription(db.Model):
    disease = db.Column(db.String, primary_key=True)
    description = db.Column(db.String)

with app.app_context():
    db.create_all()

print("✅ Tables created in disease.db")
