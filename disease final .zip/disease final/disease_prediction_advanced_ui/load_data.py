import os
import pandas as pd
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disease.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- Models ---
class SymptomSeverity(db.Model):
    symptom = db.Column(db.String, primary_key=True)
    weight = db.Column(db.Integer)

class SymptomPrecaution(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    disease = db.Column(db.String)
    precaution_1 = db.Column(db.String)
    precaution_2 = db.Column(db.String)
    precaution_3 = db.Column(db.String)
    precaution_4 = db.Column(db.String)

class SymptomDescription(db.Model):
    disease = db.Column(db.String, primary_key=True)
    description = db.Column(db.String)

# --- Helper to clean values ---
def clean(value):
    return str(value).strip() if pd.notna(value) else ""

# --- Main Data Load Function ---
def load_data():
    print("🚀 Starting data load...")

    # Ensure all files are present
    if not os.path.exists("Symptom-severity.csv"):
        print("❌ Symptom-severity.csv not found!")
        return
    if not os.path.exists("symptom_Description.xlsx"):
        print("❌ symptom_Description.xlsx not found!")
        return
    if not os.path.exists("symptom_precaution (1).xlsx"):
        print("❌ symptom_precaution (1).xlsx not found!")
        return

    # Load datasets
    severity_df = pd.read_csv("Symptom-severity.csv")
    desc_df = pd.read_excel("symptom_Description.xlsx")
    prec_df = pd.read_excel("symptom_precaution (1).xlsx")

    with app.app_context():
        db.drop_all()
        db.create_all()

        # ✅ Insert symptom severity with duplication check
        inserted = set()
        for _, row in severity_df.iterrows():
            sym = clean(row['Symptom'])
            if sym not in inserted:
                db.session.add(SymptomSeverity(
                    symptom=sym,
                    weight=int(row['weight'])
                ))
                inserted.add(sym)
        print(f"✅ Inserted {len(inserted)} unique symptoms")

        # ✅ Insert disease descriptions
        for _, row in desc_df.iterrows():
            db.session.add(SymptomDescription(
                disease=clean(row['Disease']),
                description=clean(row['Description'])
            ))
        print(f"✅ Inserted {len(desc_df)} disease descriptions")

        # ✅ Insert precautions
        for _, row in prec_df.iterrows():
            db.session.add(SymptomPrecaution(
                disease=clean(row.get('Disease')),
                precaution_1=clean(row.get('Precaution_1')),
                precaution_2=clean(row.get('Precaution_2')),
                precaution_3=clean(row.get('Precaution_3')),
                precaution_4=clean(row.get('Precaution_4')),
            ))
        print(f"✅ Inserted {len(prec_df)} precaution entries")

        try:
            db.session.commit()
            print("🎉 All data successfully committed to database.")
        except Exception as e:
            print("❌ Error during commit:", e)

# --- Run it ---
if __name__ == "__main__":
    load_data()
