import sqlite3

# Connect to SQLite database (creates it if it doesn't exist)
conn = sqlite3.connect("disease.db")
cursor = conn.cursor()

# Step 1: Create the table
cursor.execute("""
CREATE TABLE IF NOT EXISTS disease_info (
    name TEXT PRIMARY KEY,
    description TEXT,
    precautions TEXT  -- Stored as comma-separated values
)
""")

# Step 2: Insert sample data
sample_data = [
    (
        'Diabetes',
        'A chronic condition that affects how your body processes blood sugar.',
        'Exercise regularly,Monitor blood sugar,Healthy diet'
    ),
    (
        'Hypertension',
        'A condition in which the force of the blood against artery walls is too high.',
        'Reduce salt intake,Regular exercise,Manage stress'
    ),
    (
        'Migraine',
        'A neurological condition that can cause multiple symptoms including intense headaches.',
        'Avoid triggers,Take prescribed medication,Stay hydrated'
    ),
    (
        'Asthma',
        'A respiratory condition marked by spasms in the bronchi of the lungs.',
        'Use inhaler,Stay away from allergens,Avoid strenuous activity'
    ),
    (
        'COVID-19',
        'A contagious respiratory illness caused by the coronavirus.',
        'Wear a mask,Stay isolated,Consult a doctor'
    )
]

# Step 3: Insert each row
cursor.executemany("""
INSERT OR REPLACE INTO disease_info (name, description, precautions)
VALUES (?, ?, ?)
""", sample_data)

# Step 4: Save changes and close connection
conn.commit()
conn.close()

print("✅ disease.db created and populated successfully.")
