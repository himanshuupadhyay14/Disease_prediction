from flask import Flask, request, render_template
import joblib
import numpy as np
import threading
import webbrowser
import sqlite3

app = Flask(__name__, template_folder="templates")

# Load required files
model = joblib.load("model.pkl")
all_symptoms = joblib.load("symptom_list.pkl")
le = joblib.load("label_encoder.pkl")

# SQLite connection
def get_disease_info(disease_name):
    conn = sqlite3.connect("disease.db")
    cursor = conn.cursor()
    cursor.execute("SELECT description, precautions FROM disease_info WHERE name=?", (disease_name,))
    row = cursor.fetchone()
    conn.close()

    if row:
        description, precautions = row
        precaution_list = precautions.split(",") if precautions else []
        return {
            "description": description,
            "precautions": precaution_list
        }
    else:
        return {
            "description": "No description available.",
            "precautions": []
        }

@app.route('/')
def home():
    return render_template("index.html", all_symptoms=all_symptoms)

@app.route('/predict')
def predict():
    name = request.args.get("name")
    selected_symptoms = request.args.getlist("symptoms")

    # Create input vector
    input_features = [1 if symptom in selected_symptoms else 0 for symptom in all_symptoms]

    # Get top 3 predictions
    proba = model.predict_proba([input_features])[0]
    top_indices = np.argsort(proba)[-3:][::-1]

    top_diseases = []
    for idx in top_indices:
        disease_name = le.inverse_transform([idx])[0]
        info = get_disease_info(disease_name)
        top_diseases.append({
            "name": disease_name,
            "description": info["description"],
            "precautions": info["precautions"]
        })

    return render_template("result.html",
                           name=name,
                           selected_symptoms=selected_symptoms,
                           top_diseases=top_diseases)

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5001/")

if __name__ == "__main__":
    threading.Timer(1.5, open_browser).start()
    app.run(debug=False, port=5001)
